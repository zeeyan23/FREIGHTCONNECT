<section id="benefits" class="benefit-section">

    <div class="container">

        <!-- Section Header -->
        <div class="benefit-header">
            <div class="section-eyebrow">
                    <span></span>
                    Benefits
            </div>

            <h2 class="section-title">
                What's in it <span>for you</span>
            </h2>

            <p class="benefit-intro">
                See how FreightConnect membership benefits your business and supports your goal.
            </p>

        </div>


        <!-- Benefit Panels -->
        <div class="benefit-grid">


            <!--Trade Partners  -->
            <div class="benefit-panel">

                <div class="benefit-image">
                    <img src="../images/benefits/yellow_container.jpeg"
                         alt="Freight and logistics container">

                    <div class="benefit-image-label">
                        TRADE & BUSINESS
                    </div>
                </div>


                <div class="benefit-panel-content">

                    <div class="benefit-number">
                        01
                    </div>

                    <div class="benefit-heading-row">

                        <div>
                            <h3>
                                Trade Partners Members
                            </h3>

                            <p>
                                Connect with shippers, freight forwarders and
                                logistics partners worldwide.
                            </p>
                        </div>

                    </div>


                    <div class="modern-benefit-list">

                        <!-- 01 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    01
                                </span>

                                <span class="benefit-title">
                                    Buyer & Supplier Discovery
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Connect with relevant buyers, suppliers and traders
                                across international markets based on your
                                products, requirements and target markets.

                            </div>

                        </div>


                        <!-- 02 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    02
                                </span>

                                <span class="benefit-title">
                                    Trade Enquiries
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Receive relevant buying, selling and sourcing
                                enquiries from businesses looking for
                                products, suppliers or trade partners
                                across international markets.

                            </div>

                        </div>


                        <!-- 03 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    03
                                </span>

                                <span class="benefit-title">
                                    Freight Support
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Access relevant freight-forwarding members
                                for shipping, logistics and transportation
                                requirements related to your trade
                                activities.

                            </div>

                        </div>


                        <!-- 04 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    04
                                </span>

                                <span class="benefit-title">
                                    New Markets
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Explore new markets, identify potential
                                business opportunities and expand your reach
                                beyond your existing markets.

                            </div>

                        </div>


                        <!-- 05 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    05
                                </span>

                                <span class="benefit-title">
                                    Verified Connections
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Build business connections with verified companies that meet FreightConnect’s verification criteria.

                            </div>

                        </div>


                        <!-- 06 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    06
                                </span>

                                <span class="benefit-title">
                                    Business Visibility
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Showcase your company, products and business
                                capabilities to relevant buyers, suppliers
                                and potential trade partners within the
                                FreightConnect Alliance.

                            </div>

                        </div>

                        <!-- 07 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    07
                                </span>

                                <span class="benefit-title">
                                    Refer Reward
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Receive a membership discount when an eligible company you refer 
                                successfully joins the FreightConnect Alliance.

                            </div>

                        </div>

                    </div>

                </div>

            </div>


            <!-- FREIGHT & LOGISTICS-->
            <div class="benefit-panel">

                <div class="benefit-image">

                    <img src="../images/benefits/Multimodal_Port_Logistics_Hub.png"
                         alt="Multimodal port logistics hub">

                    <div class="benefit-image-label">
                        FREIGHT & LOGISTICS
                    </div>

                </div>


                <div class="benefit-panel-content">

                    <div class="benefit-number">
                        02
                    </div>

                    <div class="benefit-heading-row">

                        <div>

                            <h3>
                                Freight Forwarder Members
                            </h3>

                            <p>
                                Connect with global trade partners, 
                                discover freight opportunities, and grow your business.
                            </p>

                        </div>

                    </div>


                    <div class="modern-benefit-list">

                        <!-- 01 -->
                        <div class="modern-benefit">

                            <button type="button" class="modern-benefit-toggle pt-0">

                                <span class="benefit-number-small">
                                    01
                                </span>

                                <span class="benefit-title">
                                    Trade-Generated Freight Leads
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Receive freight opportunities arising
                                directly from trade enquiries, sourcing
                                requirements and business activity on the
                                platform.

                            </div>

                        </div>


                        <!-- 02 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    02
                                </span>

                                <span class="benefit-title">
                                    Trader & Forwarder Directory Access
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Find relevant traders, suppliers and
                                freight-forwarding companies by business
                                type, market and shipping requirements.

                            </div>

                        </div>


                        <!-- 03 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    03
                                </span>

                                <span class="benefit-title">
                                    Partner & Referral Leads
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Receive new business through referrals,
                                partner enquiries and shipment opportunities
                                from relevant freight-forwarding companies
                                across the Alliance.

                            </div>

                        </div>


                        <!-- 04 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    04
                                </span>

                                <span class="benefit-title">
                                    Territory Exclusivity
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Members may receive exclusive representation
                                for an approved territory, subject to
                                FreightConnect's territory structure and
                                membership terms.

                            </div>

                        </div>


                        <!-- 05 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    05
                                </span>

                                <span class="benefit-title">
                                    Verified Member Connections
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Build business connections with verified companies that meet 
                                FreightConnect’s verification criteria.

                            </div>

                        </div>


                        <!-- 06 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    06
                                </span>

                                <span class="benefit-title">
                                    Payment Recovery Support
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Access structured support for recovering
                                eligible unpaid invoices from qualifying
                                business transactions.

                            </div>

                        </div>

                        <!-- 07 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    07
                                </span>

                                <span class="benefit-title">
                                    Business Exchange Report
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Receive a monthly overview of business activity, member updates, trade requirements, 
                                freight opportunities and key developments within the FreightConnect Alliance.

                            </div>

                        </div>

                        <!-- 08 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    08
                                </span>

                                <span class="benefit-title">
                                    FreightConnect Briefs
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Stay informed about global trade, freight, logistics, supply chains, 
                                regulations and market trends relevant to international business.

                            </div>

                        </div>

                        <!-- 09 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    09
                                </span>

                                <span class="benefit-title">
                                    Member of the Year
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                The year’s best-performing freight forwarder member receives an award, 
                                promotional exposure and a discounted renewal rate, recognizing business activity, engagement, responsiveness and contribution to the alliance.

                            </div>

                        </div>

                        <!-- 10 -->
                        <div class="modern-benefit">

                            <button type="button"
                                    class="modern-benefit-toggle">

                                <span class="benefit-number-small">
                                    10
                                </span>

                                <span class="benefit-title">
                                    Refer & Reward
                                </span>

                                <span class="benefit-icon">
                                    +
                                </span>

                            </button>

                            <div class="modern-benefit-description">

                                Refer eligible freight forwarding companies and receive a membership discount 
                                when your referral completes the membership process and joins the alliance.

                            </div>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section>

<script>
document.querySelectorAll('.modern-benefit-toggle').forEach(function (button) {

    button.addEventListener('click', function () {

        const benefit = button.closest('.modern-benefit');

        const isOpen = benefit.classList.contains('active');


        /*
         * Close all benefits
         */
        document.querySelectorAll('.modern-benefit').forEach(function (item) {

            item.classList.remove('active');

            item.querySelector('.benefit-icon').textContent = '+';

        });


        /*
         * Open clicked benefit
         */
        if (!isOpen) {

            benefit.classList.add('active');

            benefit.querySelector('.benefit-icon').textContent = '−';

        }

    });

});
</script>