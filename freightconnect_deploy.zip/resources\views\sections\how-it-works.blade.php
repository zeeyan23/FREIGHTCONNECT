<section class="how-it-works-section" id="howitworks">
        <div class="container">
            <div class="row align-items-center">
                <div class="col">
                    <div class="row align-items-center mb-5">
                        <div class="col">
                            <div class="section-eyebrow">
                                <span></span>
                                How It Works
                            </div>
                            <h2 class="section-title">Simple process.<br><span>Global</span> possibilities.</h2>
                        </div>
                    </div>
                    <div class="row g-4">
                        <div class="col-lg-3 col-sm-6 step-col">
                            <div class="step-number">01</div>
                            <h3 class="step-title">SHARE</h3>
                            <p class="step-desc">Share a trade or freight requirement.</p>
                        </div>
                        <div class="col-lg-3 col-sm-6 step-col">
                            <div class="step-number">02</div>
                            <h3 class="step-title">DISCOVER</h3>
                            <p class="step-desc">Find relevant businesses, partners and opportunities.</p>
                        </div>
                        <div class="col-lg-3 col-sm-6 step-col">
                            <div class="step-number">03</div>
                            <h3 class="step-title">CONNECT</h3>
                            <p class="step-desc">Connect  with suitable members through FreightConnect.</p>
                        </div>
                        <div class="col-lg-3 col-sm-6 step-col">
                            <div class="step-number">04</div>
                            <h3 class="step-title">COLLABORATE</h3>
                            <p class="step-desc">Take the relationship, trade or shipment forward directly</p>
                        </div>
                    </div>
                </div>
                <div class="col-xl-3 d-none d-xl-block image-banner-col align-self-stretch"></div>
            </div>
        </div>
    </section>
