<div class="modal fade"
     id="<?php echo e($id); ?>"
     tabindex="-1"
     aria-labelledby="<?php echo e($id); ?>Label"
     aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content selection-modal">

            <div class="modal-header border-0">

                <div>
                    <span class="selection-modal-label">
                        <?php echo e($label); ?>

                    </span>

                    <h5 class="modal-title" id="<?php echo e($id); ?>Label">
                        <?php echo e($title); ?>

                    </h5>

                    <p class="mb-0">
                        <?php echo e($description); ?>

                    </p>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"></button>

            </div>

            <div class="modal-body pt-2">

                <div class="selection-options">

                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                        <a href="<?php echo e($option['url']); ?>"
                           class="selection-option">

                            <div class="selection-option-icon">
                                <i class="<?php echo e($option['icon']); ?>"></i>
                            </div>

                            <div class="selection-option-content">

                                <h6>
                                    <?php echo e($option['title']); ?>

                                </h6>

                                <p>
                                    <?php echo e($option['description']); ?>

                                </p>

                                
                            </div>

                            <i class="fa-solid fa-arrow-right selection-option-arrow"></i>

                        </a>

                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                </div>
                <?php if(!empty($info)): ?>

                    <div class="selection-modal-info">

                        <div class="selection-modal-info-title">

                            <i class="fa-solid fa-circle-info"></i>

                            <span>
                                <?php echo e($info['title']); ?>

                            </span>

                        </div>

                        <p>
                            <?php echo e($info['description']); ?>

                        </p>

                    </div>

                <?php endif; ?>

            </div>

        </div>
    </div>

</div><?php /**PATH D:\globaltrading\resources\views/components/selection-modal.blade.php ENDPATH**/ ?>