<div class="modal fade"
     id="buyerSupplierModal"
     tabindex="-1"
     aria-labelledby="buyerSupplierModalLabel"
     aria-hidden="true">

    <div class="modal-dialog modal-dialog-centered">
        <div class="modal-content buyer-supplier-modal">

            <div class="modal-header border-0">
                <div>
                    <span class="buyer-supplier-modal-label">
                        FREIGHTCONNECT
                    </span>

                    <h5 class="modal-title" id="buyerSupplierModalLabel">
                        What are you looking for?
                    </h5>

                    <p class="mb-0">
                        Choose an option to find the right trade connection.
                    </p>
                </div>

                <button type="button"
                        class="btn-close"
                        data-bs-dismiss="modal"
                        aria-label="Close"></button>
            </div>


            <div class="modal-body pt-2">

                <div class="buyer-supplier-options">

                    
                    <a href="<?php echo e(route('search.suppliers')); ?>"
                       class="buyer-supplier-option supplier-option">

                        <div class="buyer-supplier-icon">
                            <i class="fa-solid fa-boxes-stacked"></i>
                        </div>

                        <div class="buyer-supplier-content">
                            <h6>Find a Supplier</h6>

                            <p>
                                Find suppliers, manufacturers and exporters
                                for the products you need.
                            </p>
                        </div>

                        <i class="fa-solid fa-arrow-right buyer-supplier-arrow"></i>

                    </a>


                    
                    <a href="<?php echo e(route('search.buyers')); ?>"
                       class="buyer-supplier-option buyer-option">

                        <div class="buyer-supplier-icon">
                            <i class="fa-solid fa-handshake"></i>
                        </div>

                        <div class="buyer-supplier-content">
                            <h6>Find a Buyer</h6>

                            <p>
                                Find buyers, importers and trading companies
                                looking for your products.
                            </p>
                        </div>

                        <i class="fa-solid fa-arrow-right buyer-supplier-arrow"></i>

                    </a>

                </div>

            </div>

        </div>
    </div>
</div><?php /**PATH D:\globaltrading\resources\views/components/buyer-supplier-modal.blade.php ENDPATH**/ ?>