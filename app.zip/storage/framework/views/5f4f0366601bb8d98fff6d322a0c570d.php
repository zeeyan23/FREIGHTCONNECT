

<?php $__env->startSection('content'); ?>

<section class="legal-page">


<div class="container">

    
    <div class="legal-header">

        <span class="legal-label">
            <?php echo $__env->yieldContent('legal-label', 'FREIGHTCONNECT LEGAL'); ?>
        </span>

        <h1>
            <?php echo $__env->yieldContent('title'); ?>
        </h1>

        <p>
            <?php echo $__env->yieldContent('legal-description'); ?>
        </p>

        <div class="legal-updated">

            <i class="fa-regular fa-calendar"></i>

            Last updated:
            <?php echo $__env->yieldContent('updated-date', 'September 3, 2026'); ?>

        </div>

    </div>


    <div class="legal-layout">

        
        <aside class="legal-sidebar">

            <div class="legal-sidebar-card">

                <span class="legal-sidebar-title">
                    ON THIS PAGE
                </span>

                <nav class="legal-navigation">

                    <?php echo $__env->yieldContent('legal-navigation'); ?>

                </nav>

            </div>

        </aside>


        
        <article class="legal-content">

            <?php echo $__env->yieldContent('legal-content'); ?>

        </article>

    </div>

</div>


</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\globaltrading\resources\views/layouts/legal.blade.php ENDPATH**/ ?>