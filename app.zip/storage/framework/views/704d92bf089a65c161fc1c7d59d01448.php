<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <div class="container">

        <a class="navbar-brand" href="#">
            FreightConnect
        </a>

        <div class="d-flex align-items-center gap-2">

            <!-- Membership -->
            <a href="#membership" class="btn btn-primary btn-sm" data-bs-toggle="modal"
                data-bs-target="#membershipTypeModal">
                Request an Invitation for Membership
            </a>

            <!-- Supplier -->
            <a href="#supplier" class="btn btn-light btn-sm" data-bs-toggle="modal"
                data-bs-target="#buyerSupplierModal">
                Looking for a Supplier / Buyer?
            </a>

        </div>

    </div>
</nav><?php /**PATH D:\globaltrading\resources\views/sections/navbar.blade.php ENDPATH**/ ?>