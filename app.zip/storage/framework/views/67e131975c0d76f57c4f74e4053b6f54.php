

<?php $__env->startSection('title', 'External User Terms & Conditions'); ?>

<?php $__env->startSection('legal-label', 'FREIGHTCONNECT LEGAL'); ?>

<?php $__env->startSection('legal-description'); ?>
Please read these terms carefully before using FreightConnect to search for suppliers, buyers, or business opportunities.
<?php $__env->stopSection(); ?>

<?php $__env->startSection('legal-navigation'); ?>


<a href="#accurate-information">
    Accurate Information
</a>

<a href="#platform-enquiries">
    Platform & Enquiries
</a>

<a href="#verification-transactions">
    Verification & Transactions
</a>

<a href="#no-guarantee-liability">
    No Guarantee or Liability
</a>

<a href="#proper-use-account">
    Proper Use & Account
</a>


<?php $__env->stopSection(); ?>


<?php $__env->startSection('legal-content'); ?>


<section class="legal-section" id="accurate-information">

    <h2>
        <span>1.</span>
        Accurate Information
    </h2>

    <p>
        Users must provide accurate, complete and current business and contact information and update it when necessary.
    </p>

</section>


<section class="legal-section" id="platform-enquiries">

    <h2>
        <span>2.</span>
        Platform & Enquiries
    </h2>

    <p>
        FreightConnect provides a platform to search for suppliers, buyers and business opportunities and facilitates the exchange of business enquiries.
    </p>

</section>


<section class="legal-section" id="verification-transactions">

    <h2>
        <span>3.</span>
        Verification & Transactions
    </h2>

    <p>
        Users are responsible for independently verifying companies, products, pricing, credentials and other details before proceeding with any transaction. Transactions are solely between the parties involved.
    </p>

</section>


<section class="legal-section" id="no-guarantee-liability">

    <h2>
        <span>4.</span>
        No Guarantee or Liability
    </h2>

    <p>
        FreightConnect does not guarantee the authenticity, suitability, availability, performance, payment, delivery or outcome of any enquiry, company or transaction and is not a party to such transactions.
    </p>

</section>


<section class="legal-section" id="proper-use-account">

    <h2>
        <span>5.</span>
        Proper Use & Account
    </h2>

    <p>
        Users must not use FreightConnect for fraud, spam, misleading or unlawful activities, misuse information, or harm the platform or its users. FreightConnect may restrict or terminate accounts for violations.
    </p>

</section>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.legal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\globaltrading\resources\views/legal/external-terms.blade.php ENDPATH**/ ?>