<!DOCTYPE html>
<html lang="en">

<head>
    <title>FREIGHTCONNECT</title>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
    
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <link rel="stylesheet"
        href="https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.5/build/css/intlTelInput.css"/>

    <link rel="stylesheet" href="<?php echo e(asset('css/sections/about.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/contact.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/faq.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/hero.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/membership.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/navbar.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/sections/why-join.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/floating-whatsapp.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/membership/trade-partner.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/membership/freight-forwarding.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/components/selection-modal.css')); ?>">

    <link rel="stylesheet" href="<?php echo e(asset('css/search/suppliers.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/search/buyers.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth/register.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/auth/login.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('css/account/account.css')); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset('css/legal/legal.css')); ?>">

</head>

<body>

    <?php echo $__env->yieldContent('content'); ?>
    
    <?php if(
    !request()->routeIs(
        'membership.trade-partner',
        'membership.freight-forwarding',
        'search.buyers',
        'search.suppliers',
        'register',
        'legal.external-terms',
        'legal.external-privacy',
        'legal.payment-recovery',
        'legal.membership-terms',
        'legal.privacy-policy',
        'login',
        'forgot-password',
        'reset-password',
        'account'
    )): ?>
    <a href="https://wa.me/971XXXXXXXXX"
        class="whatsapp-float"
        target="_blank"
        aria-label="Chat with us on WhatsApp">
            <i class="fa-brands fa-whatsapp"></i>
    </a>
    <?php endif; ?>

    
    <script src="https://cdn.jsdelivr.net/npm/intl-tel-input@25.10.5/build/js/intlTelInput.min.js"></script>
</body>

</html><?php /**PATH D:\globaltrading\resources\views/layouts/app.blade.php ENDPATH**/ ?>