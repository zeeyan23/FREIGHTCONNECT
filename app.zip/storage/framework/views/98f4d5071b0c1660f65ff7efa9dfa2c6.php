

<?php $__env->startSection('content'); ?>

<section class="buyer-search-page">

    <div class="container">

        
        <div class="buyer-search-header">

            <span class="search-label">
                FIND A BUYER
            </span>

            <h1>
                Find the right buyers
            </h1>

            <p>
                Search for buyers interested in the products you offer.
            </p>

        </div>


        
        <div class="buyer-filter-bar">

            <form action="#" method="GET">

                <div class="buyer-filter-row">

                    
                    <div class="filter-item filter-products">

                        <label class="search-form-label">
                            Product(s)
                        </label>

                        <div id="buyer-product-fields">

                            <div class="product-input-row">

                                <input
                                    type="text"
                                    name="products[]"
                                    class="form-control"
                                    placeholder="Type product / keyword"
                                    required
                                >

                            </div>

                        </div>

                        <button
                            type="button"
                            id="add-buyer-product"
                            class="add-product-btn"
                        >
                            <i class="fa-solid fa-plus"></i>
                            Add product
                        </button>

                    </div>


                    
                    <div class="filter-item">

                        <label for="buyer_country" class="search-form-label">
                            Buyer Country
                        </label>

                        <select
                            name="country"
                            id="buyer_country"
                            class="form-select"
                            required
                        >

                            <option value="" selected disabled>
                                Select Country
                            </option>

                            <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $code => $country): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                <option value="<?php echo e($code); ?>">
                                    <?php echo e($country); ?>

                                </option>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </select>

                    </div>


                    
                    <div class="filter-item">

                        <label for="buyer_quantity" class="search-form-label">
                            Quantity
                            <span>(Optional)</span>
                        </label>

                        <input
                            type="text"
                            name="quantity"
                            id="buyer_quantity"
                            class="form-control"
                            placeholder="e.g. 500 units"
                        >

                    </div>


                    
                    <div class="filter-item filter-shipping">

                        <label class="search-form-label">
                            Logistics / Shipping Required?
                        </label>

                        <div class="shipping-options">

                            <label class="shipping-option">

                                <input
                                    type="radio"
                                    name="shipping_required"
                                    value="yes"
                                >

                                <span>Yes</span>

                            </label>


                            <label class="shipping-option">

                                <input
                                    type="radio"
                                    name="shipping_required"
                                    value="no"
                                >

                                <span>No</span>

                            </label>

                        </div>

                    </div>


                    
                    <div class="filter-search">

                        <button
                            type="submit"
                            class="buyer-search-btn"
                        >
                            <i class="fa-solid fa-magnifying-glass"></i>
                            Search Buyers
                        </button>

                    </div>

                </div>

            </form>

        </div>


        
        <div class="buyer-results-section">

            <div class="buyer-results-header">

                <div>

                    <span class="results-label">
                        SEARCH RESULTS
                    </span>

                    <h2>
                        Buyers interested in your products
                    </h2>

                </div>

                <span class="results-count">
                    18 Buyers Found
                </span>

            </div>


            
            <div class="buyer-result-card">

                <div class="buyer-result-select">

                    <input
                        type="checkbox"
                        class="buyer-checkbox"
                        name="buyers[]"
                        value="1"
                    >

                </div>


                <div class="buyer-result-content">

                    <div class="buyer-result-top">

                        <div>

                            <h3>
                                ABC Trading LLC
                            </h3>

                            <p class="buyer-location">

                                <i class="fa-solid fa-location-dot"></i>

                                Dubai, UAE

                            </p>

                        </div>


                        <span class="buyer-type">
                            Trading Company
                        </span>

                    </div>


                    
                    <div class="interested-products">

                        <span class="interested-label">
                            Interested in
                        </span>

                        <div class="interested-product-list">

                            <span class="interested-product">

                                <i class="fa-solid fa-check"></i>

                                Industrial Pumps

                            </span>


                            <span class="interested-product">

                                <i class="fa-solid fa-check"></i>

                                Compressors

                            </span>

                        </div>

                    </div>


                    <div class="buyer-result-bottom">

                        <span class="buyer-match">

                            <i class="fa-solid fa-circle-check"></i>

                            Strong Match

                        </span>


                        <a
                            href="#"
                            class="view-company-btn"
                        >
                            View Company

                            <i class="fa-solid fa-arrow-right"></i>

                        </a>

                    </div>

                </div>

            </div>


            
            <div class="buyer-result-card">

                <div class="buyer-result-select">

                    <input
                        type="checkbox"
                        class="buyer-checkbox"
                        name="buyers[]"
                        value="2"
                    >

                </div>


                <div class="buyer-result-content">

                    <div class="buyer-result-top">

                        <div>

                            <h3>
                                Global Equipment Trading
                            </h3>

                            <p class="buyer-location">

                                <i class="fa-solid fa-location-dot"></i>

                                Abu Dhabi, UAE

                            </p>

                        </div>


                        <span class="buyer-type">
                            Importer

                        </span>

                    </div>


                    <div class="interested-products">

                        <span class="interested-label">
                            Interested in
                        </span>

                        <div class="interested-product-list">

                            <span class="interested-product">

                                <i class="fa-solid fa-check"></i>

                                Industrial Pumps

                            </span>

                        </div>

                    </div>


                    <div class="buyer-result-bottom">

                        <span class="buyer-match">

                            <i class="fa-solid fa-circle-check"></i>

                            Good Match

                        </span>


                        <a
                            href="#"
                            class="view-company-btn"
                        >
                            View Company

                            <i class="fa-solid fa-arrow-right"></i>

                        </a>

                    </div>

                </div>

            </div>


            
            <div class="send-inquiry-wrapper">

                <div class="selected-buyer-info">

                    <i class="fa-solid fa-circle-info"></i>

                    <span>
                        Select one or more buyers to send an enquiry.
                    </span>

                </div>


                <button
                    type="button"
                    class="send-inquiry-btn"
                    data-bs-toggle="modal"
                    data-bs-target="#inquiryAccountModal"
                >
                    Send Inquiry

                    <i class="fa-solid fa-paper-plane"></i>

                </button>

            </div>

        </div>

    </div>

</section>


<script>
document.addEventListener('DOMContentLoaded', function () {

    const addProductButton =
        document.getElementById('add-buyer-product');

    const productFields =
        document.getElementById('buyer-product-fields');


    // Add product
    addProductButton.addEventListener('click', function () {

        const productRow =
            document.createElement('div');

        productRow.classList.add('product-input-row');

        productRow.innerHTML = `
            <input
                type="text"
                name="products[]"
                class="form-control"
                placeholder="Type another product / keyword"
                required
            >

            <button
                type="button"
                class="remove-product"
                aria-label="Remove product"
            >
                <i class="fa-solid fa-xmark"></i>
            </button>
        `;

        productFields.appendChild(productRow);

    });


    // Remove product
    productFields.addEventListener('click', function (event) {

        const removeButton =
            event.target.closest('.remove-product');

        if (!removeButton) {
            return;
        }

        removeButton
            .closest('.product-input-row')
            .remove();

    });

});
</script>

    <?php echo $__env->make('components.selection-modal', [
        'id' => 'inquiryAccountModal',
        'label' => 'INQUIRY',
        'title' => 'Continue with Inquiry',
        'description' => 'Create a free account or log in to continue with your enquiry.',
        'options' => [
            [
                'title' => 'Create Free Account',
                'description' => 'Save your business details and send enquiries faster.',
                'icon' => 'fa-solid fa-user-plus',
                'url' => route('register'),
            ],
            [
                'title' => 'Log In',
                'description' => 'Already have a FreightConnect account?',
                'icon' => 'fa-solid fa-right-to-bracket',
                'url' => route('login'),
            ],
        ],
        'info' => [
            'title' => 'Why create an account?',
            'description' => 'Your free account allows you to save your business details for future enquiries, submit enquiries to multiple companies without repeatedly entering your information, and receive relevant supplier/business opportunities from FreightConnect when available.',
        ],
    ], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH D:\globaltrading\resources\views/search/buyers.blade.php ENDPATH**/ ?>