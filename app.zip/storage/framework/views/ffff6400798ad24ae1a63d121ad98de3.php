<section id="contact" class="contact-section py-5">

    <div class="container py-5">

        <div class="contact-card">

            <div class="row align-items-center g-5">

                <!-- Left Content -->
                <div class="col-lg-6">

                    <span class="contact-label">
                        GET IN TOUCH
                    </span>

                    <h2 class="contact-title">
                        Let’s <span>Connect</span>
                    </h2>

                    <p class="contact-description">
                        Have a question about FreightConnect, membership
                        or becoming a Trade Partner?
                    </p>

                    <p class="contact-subtext">
                        We’re happy to hear from you.
                    </p>

                </div>


                <!-- Right Contact Details -->
                <div class="col-lg-6">

                    <div class="contact-details">

                        <!-- Email -->
                        <a href="mailto:info@freightconnect.info"
                           class="contact-item">

                            <div class="contact-icon">
                                <i class="fa-solid fa-envelope"></i>
                            </div>

                            <div>
                                <span>Email</span>
                                <strong>info@freightconnect.info</strong>
                            </div>

                        </a>


                        <!-- WhatsApp -->
                        <a href="#"
                           class="contact-item">

                            <div class="contact-icon whatsapp-icon">
                                <i class="fa-brands fa-whatsapp"></i>
                            </div>

                            <div>
                                <span>WhatsApp</span>
                                <strong>+971 XX XXX XXXX</strong>
                            </div>

                        </a>


                        <!-- Membership -->
                        <div class="membership-contact">

                            <div class="membership-contact-title">
                                <i class="fa-solid fa-star"></i>

                                For membership enquiries
                            </div>

                            <a href="mailto:sales@freightconnect.info">
                                sales@freightconnect.info
                            </a>

                            <span>or</span>

                            <a href="mailto:info@freightconnect.info">
                                info@freightconnect.info
                            </a>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>

</section><?php /**PATH D:\globaltrading\resources\views/sections/contact.blade.php ENDPATH**/ ?>